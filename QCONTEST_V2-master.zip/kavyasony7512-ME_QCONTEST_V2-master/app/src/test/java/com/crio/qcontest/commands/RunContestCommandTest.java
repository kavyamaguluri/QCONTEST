// package com.crio.qcontest.commands;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;

// import com.crio.qcontest.services.ContestService;

// import java.util.List;

// import static org.mockito.Mockito.*;

// public class RunContestCommandTest {
    
//     private ContestService contestService;
//     private RunContestCommand runContestCommand;

//     @BeforeEach
//     void setUp() {
//         contestService = mock(ContestService.class);
//         runContestCommand = new RunContestCommand(contestService, null);
//     }

//     @Test
//     void testInvoke() {
//         // Set up
//         Long contestId = 1L;
//         Long contestCreator = 2L;

//         // Call method
//         runContestCommand.invoke(List.of("RunContest", contestId.toString(), contestCreator.toString()));

//         // Verify
//         verify(contestService).runContest(contestId, contestCreator);
//     }
// }
package com.crio.qcontest.commands;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import com.crio.qcontest.entities.Permission;
import com.crio.qcontest.entities.Role;
import com.crio.qcontest.entities.User;
import com.crio.qcontest.services.ContestService;
import com.crio.qcontest.services.RBACService;

import java.util.List;

public class RunContestCommandTest {

    private ContestService contestService;
    private RBACService rbacService;
    private RunContestCommand runContestCommand;

    @BeforeEach
    void setUp() {
        contestService = mock(ContestService.class);
        rbacService = mock(RBACService.class);
        runContestCommand = new RunContestCommand(contestService, rbacService);
    }

    // @Test
    // void testInvoke_ValidArguments_AdminUser() {
    //     // Set up
    //     Long contestId = 123L;
    //     Long userId = 1L;  // Admin user
    //     List<String> tokens = List.of("RUN_CONTEST", contestId.toString(), userId.toString());

    //     User adminUser = new User("Alice");
    //     when(rbacService.hasPermission(adminUser, Permission.RUN_CONTEST)).thenReturn(true);

    //     // Call method
    //     runContestCommand.invoke(tokens);

    //     // Verify
    //     verify(contestService, times(1)).runContest(contestId, userId);
    // }

    @Test
    void testInvoke_ValidArguments_RegularUser() {
        // Set up
        Long contestId = 123L;
        Long userId = 2L;  // Regular user
        List<String> tokens = List.of("RUN_CONTEST", contestId.toString(), userId.toString());

        User regularUser = new User("Bob");
        when(rbacService.hasPermission(regularUser, Permission.RUN_CONTEST)).thenReturn(false);

        // Call method
        runContestCommand.invoke(tokens);

        // Verify
        verify(contestService, never()).runContest(anyLong(), anyLong());
        // Optionally check for console output like ACCESS_DENIED, if needed
    }

    @Test
    void testInvoke_InsufficientArguments() {
        // Set up
        List<String> tokens = List.of("RUN_CONTEST");

        // Call method
        runContestCommand.invoke(tokens);

        // Verify
        verify(contestService, never()).runContest(anyLong(), anyLong());
    }

    @Test
    void testInvoke_InvalidArguments() {
        // Set up
        List<String> tokens = List.of("RUN_CONTEST", "invalid", "2");

        // Call method
        runContestCommand.invoke(tokens);

        // Verify
        verify(contestService, never()).runContest(anyLong(), anyLong());
    }

    @Test
    void testInvoke_UserDoesNotExist() {
        // Set up
        Long contestId = 123L;
        Long userId = 999L;  // Non-existing user
        List<String> tokens = List.of("RUN_CONTEST", contestId.toString(), userId.toString());

        // Call method
        runContestCommand.invoke(tokens);

        // Verify
        verify(contestService, never()).runContest(anyLong(), anyLong());
        // Optionally check for console output like INVALID_ARGUMENTS, if needed
    }
}
