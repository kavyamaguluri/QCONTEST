package com.crio.qcontest.commands;

import java.util.List;
import com.crio.qcontest.entities.Contestant;
import com.crio.qcontest.services.ContestService;

public class ContestHistoryCommand implements ICommand {

    private final ContestService contestService;

    public ContestHistoryCommand(ContestService contestService) {
        this.contestService = contestService;
    }

    @Override
    public void invoke(List<String> tokens) {
        if (tokens.size() < 2) {
            System.out.println("INVALID_INPUT");
            return;
        }

        Long contestId = Long.parseLong(tokens.get(1));

        try {
            List<Contestant> contestants = contestService.contestHistory(contestId);

            // Sort contestants by total score in descending order
            contestants.sort((c1, c2) -> Integer.compare(c2.getTotalScore(), c1.getTotalScore()));

            StringBuilder output = new StringBuilder();

            for (int i = 0; i < contestants.size(); i++) {
                Contestant contestant = contestants.get(i);
                output.append(contestant.getUser().getName())
                      .append(" : ")
                      .append(contestant.getTotalScore())
                      .append(" [")
                      .append(contestants.size() - i) 
                      .append("]\n");
            }

            System.out.print(output.toString().trim());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}


