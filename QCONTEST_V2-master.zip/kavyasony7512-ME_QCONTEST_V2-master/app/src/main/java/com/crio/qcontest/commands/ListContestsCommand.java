package com.crio.qcontest.commands;

import java.util.List;
import java.util.stream.Collectors;

import com.crio.qcontest.entities.Contest;
import com.crio.qcontest.entities.DifficultyLevel;
import com.crio.qcontest.services.ContestService;

public class ListContestsCommand implements ICommand {

    private final ContestService contestService;

    public ListContestsCommand(ContestService contestService) {
        this.contestService = contestService;
    }

    @Override
    public void invoke(List<String> tokens) {
        try {
            List<Contest> contests;
            if (tokens.size() == 1) {
                contests = contestService.listContests(null);
            } else if (tokens.size() == 2) {
                DifficultyLevel level = DifficultyLevel.valueOf(tokens.get(1).toUpperCase());
                contests = contestService.listContests(level);
            } else {
                System.out.println("INVALID_COMMAND_FORMAT");
                return;
            }

            if (contests.isEmpty()) {
                System.out.println("NO_CONTESTS_FOUND");
            } else {
                // Format the output as a list-like structure
                String contestsOutput = contests.stream()
                                                .map(Contest::toString)
                                                .collect(Collectors.joining(", ", "[", "]"));
                System.out.println(contestsOutput);
            }
        } catch (IllegalArgumentException e) {
            System.out.println("INVALID_DIFFICULTY_LEVEL");
        }
    }
}

