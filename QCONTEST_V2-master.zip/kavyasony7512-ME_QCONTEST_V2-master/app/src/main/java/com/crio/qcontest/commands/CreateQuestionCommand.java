package com.crio.qcontest.commands;

import java.util.List;

import com.crio.qcontest.entities.DifficultyLevel;
import com.crio.qcontest.entities.Question;
import com.crio.qcontest.services.QuestionService;

public class CreateQuestionCommand implements ICommand{
    private final QuestionService questionService;

    public CreateQuestionCommand(QuestionService questionService) {
        this.questionService = questionService;
    }

    @Override
    public void invoke(List<String> tokens) {
        if (tokens.size() < 4) {
            throw new RuntimeException("INVALID_INPUT");
        }

        String title = tokens.get(1);
        DifficultyLevel level = DifficultyLevel.valueOf(tokens.get(2).toUpperCase());
        Integer difficultyScore = Integer.parseInt(tokens.get(3));

        try {
            Question question = questionService.createQuestion(title, level, difficultyScore);
            System.out.println( "Question Id:" + " " +question.getId());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

}
