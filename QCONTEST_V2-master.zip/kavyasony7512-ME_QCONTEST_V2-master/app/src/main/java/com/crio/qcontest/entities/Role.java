package com.crio.qcontest.entities;

public enum Role {
    ADMIN,
    USER
}
