package com.crio.qcontest.commands;

import java.util.List;

import com.crio.qcontest.entities.User;
import com.crio.qcontest.services.UserService;

public class CreateUserCommand implements ICommand{

    private final UserService userService;

    public CreateUserCommand(UserService userService) {
        this.userService = userService;
    }

    @Override
    public void invoke(List<String> tokens) {
        if (tokens.size() != 2) {
            System.out.println("INVALID_COMMAND_FORMAT");
            return;
        }

        String userName = tokens.get(1);
        if (userName == null || userName.trim().isEmpty()) {
            System.out.println("INVALID_USER_NAME");
            return;
        }

        try {
            User newUser = userService.createUser(userName);
            System.out.println(newUser);
        } catch (Exception e) {
            System.out.println("ERROR_CREATING_USER");
        }
    }
    
}

