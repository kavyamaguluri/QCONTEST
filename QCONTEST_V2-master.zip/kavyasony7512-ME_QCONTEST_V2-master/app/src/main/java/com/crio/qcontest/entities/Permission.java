package com.crio.qcontest.entities;

public enum Permission {
    RUN_CONTEST,
    VIEW_CONTESTS,
    CREATE_CONTEST,
    EDIT_CONTEST
}
