package com.crio.qcontest.commands;

import java.util.List;

import com.crio.qcontest.entities.Contestant;
import com.crio.qcontest.services.ContestService;

public class AttendContestCommand implements ICommand {

    private final ContestService contestService;

    public AttendContestCommand(ContestService contestService) {
        this.contestService = contestService;
    }

    @Override
    public void invoke(List<String> tokens) {
        if (tokens.size() < 3) {
            System.out.println("INVALID_INPUT");
            return;
        }
    
        Long contestId = Long.parseLong(tokens.get(1));
        Long userId = Long.parseLong(tokens.get(2));
    
        try {
            Contestant contestant = contestService.attendContest(contestId, userId);
            System.out.println(contestant.toString()); // Print the contestant's toString() output
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
