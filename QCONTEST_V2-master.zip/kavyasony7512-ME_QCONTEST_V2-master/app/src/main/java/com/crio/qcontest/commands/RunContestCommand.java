package com.crio.qcontest.commands;

import java.util.List;
import com.crio.qcontest.entities.Permission;
import com.crio.qcontest.entities.Role;
import com.crio.qcontest.entities.User;
import com.crio.qcontest.services.ContestService;
import com.crio.qcontest.services.RBACService;

public class RunContestCommand implements ICommand {

    private final ContestService contestService;
    private final RBACService rbacService;

    // Constructor to inject services
    public RunContestCommand(ContestService contestService, RBACService rbacService) {
        this.contestService = contestService;
        this.rbacService = rbacService;
    }

    @Override
    public void invoke(List<String> tokens) {
        if (tokens.size() < 3) {
            System.out.println("INSUFFICIENT_ARGUMENTS");
            return;
        }

        try {
            Long contestId = Long.parseLong(tokens.get(1));
            Long userId = Long.parseLong(tokens.get(2));

            // Retrieve the user by ID (In a real-world scenario, you'd fetch this from a database or in-memory store)
            User user = getUserById(userId);

            // RBAC check to verify if the user has permission to run the contest
            if (!rbacService.hasPermission(user, Permission.RUN_CONTEST)) {
                System.out.println("ACCESS_DENIED");
                return;
            }

            // If permission is granted, proceed with running the contest
            contestService.runContest(contestId, userId);
            System.out.println("Contest has been run successfully.");
        } catch (NumberFormatException e) {
            System.out.println("INVALID_ARGUMENTS");
        } catch (RuntimeException e) {
            System.out.println(e.getMessage());
        }
    }

    // Simulated method to fetch a user (this would be replaced with actual logic to fetch user from your system)
    private User getUserById(Long userId) {
        // For simplicity, hardcoding user details here. In a real app, this would be fetched from a database or in-memory store.
        if (userId == 1L) {
            return new User("Alice");  // Admin user
        } else {
            return new User("Bob");  // Regular user
        }
    }
}
