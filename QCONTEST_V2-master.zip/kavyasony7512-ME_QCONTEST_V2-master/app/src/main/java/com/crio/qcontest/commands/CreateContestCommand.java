package com.crio.qcontest.commands;

import java.util.List;

import com.crio.qcontest.entities.Contest;
import com.crio.qcontest.entities.DifficultyLevel;
import com.crio.qcontest.services.ContestService;

public class CreateContestCommand implements ICommand {

    private final ContestService contestService; 

    public CreateContestCommand(ContestService contestService) {
        this.contestService = contestService;
    }

    @Override
    public void invoke(List<String> tokens) {
        if (tokens.size() < 5) {
            throw new RuntimeException("INVALID_INPUT");
        }

        String contestName = tokens.get(1);
        DifficultyLevel difficultyLevel = DifficultyLevel.valueOf(tokens.get(2).toUpperCase());
        Long userId = Long.parseLong(tokens.get(3));
        Integer numOfQuestions = Integer.parseInt(tokens.get(4));

        try {
            Contest contest = contestService.createContest(contestName, difficultyLevel, userId, numOfQuestions);
            System.out.println( "Contest Id:" + " " +contest.getId());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
}
