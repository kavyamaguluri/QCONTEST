package com.crio.qcontest.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.crio.qcontest.entities.Permission;
import com.crio.qcontest.entities.Role;
import com.crio.qcontest.entities.User;

public class RBACService {
    private static final Map<Role, List<Permission>> rolePermissions = new HashMap<>();

    static {
        // Define the permissions for each role
        rolePermissions.put(Role.ADMIN, List.of(Permission.RUN_CONTEST, Permission.VIEW_CONTESTS, Permission.CREATE_CONTEST, Permission.EDIT_CONTEST));
        rolePermissions.put(Role.USER, List.of(Permission.VIEW_CONTESTS));  // Limited permissions for USER
    }

    public boolean hasPermission(User user, Permission permission) {
        // Check if the user has the given permission based on their roles
        for (Role role : user.getRoles()) {
            List<Permission> permissions = rolePermissions.get(role);
            if (permissions != null && permissions.contains(permission)) {
                return true;
            }
        }
        return false;
    }
}

