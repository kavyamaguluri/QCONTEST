package com.crio.qcontest.commands;

import java.util.List;
import java.util.stream.Collectors;

import com.crio.qcontest.entities.DifficultyLevel;
import com.crio.qcontest.entities.Question;
import com.crio.qcontest.services.QuestionService;

public class ListQuestionsCommand implements ICommand {

    private final QuestionService questionService;

    public ListQuestionsCommand(QuestionService questionService) {
        this.questionService = questionService;
    }

    @Override
    public void invoke(List<String> tokens) {
        DifficultyLevel level = null;

        if (tokens.size() > 1) {
            try {
                level = DifficultyLevel.valueOf(tokens.get(1).toUpperCase());
            } catch (IllegalArgumentException e) {
                System.out.println("INVALID_DIFFICULTY_LEVEL");
                return;
            }
        }

        List<Question> questions = questionService.listQuestions(level);
        if (questions.isEmpty()) {
            System.out.println("No questions found.");
        } else {
            String questionsOutput = questions.stream()
                                              .map(Question::toString)
                                              .collect(Collectors.joining(", ", "[", "]"));
            System.out.println(questionsOutput);
        }
    }
}

